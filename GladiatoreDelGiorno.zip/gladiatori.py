import pandas as pd
from PIL import Image, ImageDraw, ImageFont
import os

# Carica i dati
df = pd.read_csv("dati.csv")
df = df.sort_values("Post", ascending=False).reset_index(drop=True)

# Salva una classifica aggiornata
output_path = "results/classifica.csv"
df.to_csv(output_path, index=False)

# Crea immagine con classifica
img = Image.new("RGB", (400, 200), color=(255, 255, 255))
draw = ImageDraw.Draw(img)
font = ImageFont.load_default()
y = 20
draw.text((10, 0), "Top Gladiatori di #ArenaNummus", fill=(0, 0, 0), font=font)
for i, row in df.iterrows():
    draw.text((10, y), f"{i+1}. {row['Nome']} - {row['Post']} post", fill=(0, 0, 0), font=font)
    y += 20

img.save("results/classifica.png")
